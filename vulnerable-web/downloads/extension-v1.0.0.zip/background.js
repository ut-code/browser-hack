chrome.runtime.onInstalled.addListener(()=>{console.log("拡張機能がインストールされました！")});chrome.action.onClicked.addListener(async e=>{await chrome.sidePanel.open({windowId:e.windowId,tabId:e.id})});
